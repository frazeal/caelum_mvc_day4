﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BlogWeb.Models.Dominio {

    public class Usuario {

        public virtual int Id { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo")]
        public virtual string Nome { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo")]
        public virtual string Login { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo")]
        public virtual string Password { get; set; }

        [Required(ErrorMessage = "Por favor preencha o campo")]
        [EmailAddress]
        public virtual string Email { get; set; }
    }

}